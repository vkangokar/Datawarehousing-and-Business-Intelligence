--
-- ER/Studio Data Architect SQL Code Generation
-- Project :      Chinook_DimensionalModel.DM1
--
-- Date Created : Wednesday, February 06, 2019 18:45:28
-- Target DBMS : PostgreSQL 9.x
--

-- 
-- TABLE: "Album" 
--

CREATE TABLE "Album"(
    "AlbumID"   varchar(160)    NOT NULL,
    "Title"     varchar(100)    NOT NULL,
    "ArtistID"  int4            NOT NULL,
    CONSTRAINT "PK10" PRIMARY KEY ("AlbumID")
)
;



-- 
-- TABLE: "Artist" 
--

CREATE TABLE "Artist"(
    "ArtistID"  int4            NOT NULL,
    "Name"      varchar(120),
    CONSTRAINT "PK11" PRIMARY KEY ("ArtistID")
)
;



-- 
-- TABLE: "Customer" 
--

CREATE TABLE "Customer"(
    "CustomerID"  int4           NOT NULL,
    "Phone"       varchar(24),
    "Fax"         varchar(24),
    "Email"       varchar(60)    NOT NULL,
    "FirstName"   varchar(40)    NOT NULL,
    "LastName"    varchar(20)    NOT NULL,
    "Company"     varchar(80),
    "Address"     varchar(70),
    "City"        varchar(40),
    "State"       varchar(40),
    "Country"     varchar(40),
    "PostalCode"  varchar(10),
    "EmployeeID"  int4,
    CONSTRAINT "PK4" PRIMARY KEY ("CustomerID")
)
;



-- 
-- TABLE: "Dim.Employee" 
--

CREATE TABLE "Dim.Employee"(
    "EmployeeID"  int4           NOT NULL,
    "ReportsTo"   int4,
    "LastName"    varchar(20)    NOT NULL,
    "FirstName"   varchar(20)    NOT NULL,
    "Title"       varchar(10),
    "Birthdate"   timestamp,
    "HireDate"    timestamp,
    "Address"     varchar(70),
    "City"        varchar(40),
    "State"       varchar(40),
    "Country"     varchar(40),
    "PostalCode"  varchar(10),
    "Phone"       varchar(24),
    "Fax"         varchar(24),
    "Email"       varchar(60),
    CONSTRAINT "PK5" PRIMARY KEY ("EmployeeID")
)
;



-- 
-- TABLE: "Fact.Invoice" 
--

CREATE TABLE "Fact.Invoice"(
    "InvoiceID"       varchar(30)    NOT NULL,
    "InvoiceDate"     date           NOT NULL,
    "BillingAddress"  varchar(30)    NOT NULL,
    "BillingCity"     varchar(30)    NOT NULL,
    "BillingState"    varchar(30)    NOT NULL,
    "BillingCountry"  varchar(30)    NOT NULL,
    "BillingZipCode"  varchar(10)    NOT NULL,
    "Total"           float4         NOT NULL,
    "CustomerID"      int4           NOT NULL
)
;



-- 
-- TABLE: "Fact.Track" 
--

CREATE TABLE "Fact.Track"(
    "TrackID"       int4              NOT NULL,
    "Name"          varchar(200)      NOT NULL,
    "Composer"      varchar(220)      NOT NULL,
    "Milliseconds"  int4              NOT NULL,
    "Bytes"         int4,
    "UnitPrice"     numeric(10, 2)    NOT NULL,
    "MediaTypeID"   int4              NOT NULL,
    "GenreID"       int4,
    "AlbumID"       varchar(160),
    CONSTRAINT "PK2" PRIMARY KEY ("TrackID")
)
;



-- 
-- TABLE: "Genre" 
--

CREATE TABLE "Genre"(
    "GenreID"  int4            NOT NULL,
    "Name"     varchar(120),
    CONSTRAINT "PK9" PRIMARY KEY ("GenreID")
)
;



-- 
-- TABLE: "InvoiceLine" 
--

CREATE TABLE "InvoiceLine"(
    "InvoiceLineID"  int4              NOT NULL,
    "UnitPrice"      numeric(10, 2)    NOT NULL,
    "Quantity"       int4              NOT NULL,
    "TrackID"        int4              NOT NULL,
    CONSTRAINT "PK3" PRIMARY KEY ("InvoiceLineID")
)
;



-- 
-- TABLE: "MediaType" 
--

CREATE TABLE "MediaType"(
    "MediaTypeID"  int4            NOT NULL,
    "Name"         varchar(120),
    CONSTRAINT "PK8" PRIMARY KEY ("MediaTypeID")
)
;



-- 
-- TABLE: "Playlist" 
--

CREATE TABLE "Playlist"(
    "PlaylistID"  int4            NOT NULL,
    "Name"        varchar(120),
    CONSTRAINT "PK7" PRIMARY KEY ("PlaylistID")
)
;



-- 
-- TABLE: "PlaylistTrack" 
--

CREATE TABLE "PlaylistTrack"(
    "TrackID"     int4    NOT NULL,
    "PlaylistID"  int4    NOT NULL,
    CONSTRAINT "PK6" PRIMARY KEY ("TrackID", "PlaylistID")
)
;



-- 
-- TABLE: "Album" 
--

ALTER TABLE "Album" ADD CONSTRAINT "RefArtist6" 
    FOREIGN KEY ("ArtistID")
    REFERENCES "Artist"("ArtistID")
;


-- 
-- TABLE: "Customer" 
--

ALTER TABLE "Customer" ADD CONSTRAINT "RefDim.Employee8" 
    FOREIGN KEY ("EmployeeID")
    REFERENCES "Dim.Employee"("EmployeeID")
;


-- 
-- TABLE: "Dim.Employee" 
--

ALTER TABLE "Dim.Employee" ADD CONSTRAINT "RefDim.Employee7" 
    FOREIGN KEY ("ReportsTo")
    REFERENCES "Dim.Employee"("EmployeeID")
;


-- 
-- TABLE: "Fact.Invoice" 
--

ALTER TABLE "Fact.Invoice" ADD CONSTRAINT "RefCustomer9" 
    FOREIGN KEY ("CustomerID")
    REFERENCES "Customer"("CustomerID")
;


-- 
-- TABLE: "Fact.Track" 
--

ALTER TABLE "Fact.Track" ADD CONSTRAINT "RefMediaType3" 
    FOREIGN KEY ("MediaTypeID")
    REFERENCES "MediaType"("MediaTypeID")
;

ALTER TABLE "Fact.Track" ADD CONSTRAINT "RefGenre4" 
    FOREIGN KEY ("GenreID")
    REFERENCES "Genre"("GenreID")
;

ALTER TABLE "Fact.Track" ADD CONSTRAINT "RefAlbum5" 
    FOREIGN KEY ("AlbumID")
    REFERENCES "Album"("AlbumID")
;


-- 
-- TABLE: "InvoiceLine" 
--

ALTER TABLE "InvoiceLine" ADD CONSTRAINT "RefFact.Track11" 
    FOREIGN KEY ("TrackID")
    REFERENCES "Fact.Track"("TrackID")
;


-- 
-- TABLE: "PlaylistTrack" 
--

ALTER TABLE "PlaylistTrack" ADD CONSTRAINT "RefFact.Track1" 
    FOREIGN KEY ("TrackID")
    REFERENCES "Fact.Track"("TrackID")
;

ALTER TABLE "PlaylistTrack" ADD CONSTRAINT "RefPlaylist2" 
    FOREIGN KEY ("PlaylistID")
    REFERENCES "Playlist"("PlaylistID")
;


