--
-- ER/Studio Data Architect SQL Code Generation
-- Project :      Chinook_DimensionalModel.DM1
--
-- Date Created : Wednesday, February 06, 2019 18:48:31
-- Target DBMS : MySQL 5.x
--

-- 
-- TABLE: Album 
--

CREATE TABLE Album(
    AlbumID     NATIONAL VARCHAR(160)    NOT NULL,
    Title       NATIONAL VARCHAR(100)    NOT NULL,
    ArtistID    INT                      NOT NULL,
    PRIMARY KEY (AlbumID)
)ENGINE=MYISAM
;



-- 
-- TABLE: Artist 
--

CREATE TABLE Artist(
    ArtistID    INT                      NOT NULL,
    Name        NATIONAL VARCHAR(120),
    PRIMARY KEY (ArtistID)
)ENGINE=MYISAM
;



-- 
-- TABLE: Customer 
--

CREATE TABLE Customer(
    CustomerID    INT                     NOT NULL,
    Phone         NATIONAL VARCHAR(24),
    Fax           NATIONAL VARCHAR(24),
    Email         NATIONAL VARCHAR(60)    NOT NULL,
    FirstName     NATIONAL VARCHAR(40)    NOT NULL,
    LastName      NATIONAL VARCHAR(20)    NOT NULL,
    Company       NATIONAL VARCHAR(80),
    Address       NATIONAL VARCHAR(70),
    City          NATIONAL VARCHAR(40),
    State         NATIONAL VARCHAR(40),
    Country       NATIONAL VARCHAR(40),
    PostalCode    NATIONAL VARCHAR(10),
    EmployeeID    INT,
    PRIMARY KEY (CustomerID)
)ENGINE=MYISAM
;



-- 
-- TABLE: `Dim.Employee` 
--

CREATE TABLE `Dim.Employee`(
    EmployeeID    INT                     NOT NULL,
    ReportsTo     INT,
    LastName      NATIONAL VARCHAR(20)    NOT NULL,
    FirstName     NATIONAL VARCHAR(20)    NOT NULL,
    Title         NATIONAL VARCHAR(10),
    Birthdate     DATETIME,
    HireDate      DATETIME,
    Address       NATIONAL VARCHAR(70),
    City          NATIONAL VARCHAR(40),
    State         NATIONAL VARCHAR(40),
    Country       NATIONAL VARCHAR(40),
    PostalCode    NATIONAL VARCHAR(10),
    Phone         NATIONAL VARCHAR(24),
    Fax           NATIONAL VARCHAR(24),
    Email         NATIONAL VARCHAR(60),
    PRIMARY KEY (EmployeeID)
)ENGINE=MYISAM
;



-- 
-- TABLE: `Fact.Invoice` 
--

CREATE TABLE `Fact.Invoice`(
    InvoiceID         VARCHAR(30)    NOT NULL,
    InvoiceDate       DATE           NOT NULL,
    BillingAddress    VARCHAR(30)    NOT NULL,
    BillingCity       VARCHAR(30)    NOT NULL,
    BillingState      VARCHAR(30)    NOT NULL,
    BillingCountry    VARCHAR(30)    NOT NULL,
    BillingZipCode    VARCHAR(10)    NOT NULL,
    Total             FLOAT(8, 0)    NOT NULL,
    CustomerID        INT            NOT NULL
)ENGINE=MYISAM
;



-- 
-- TABLE: `Fact.Track` 
--

CREATE TABLE `Fact.Track`(
    TrackID         INT                      NOT NULL,
    Name            NATIONAL VARCHAR(200)    NOT NULL,
    Composer        NATIONAL VARCHAR(220)    NOT NULL,
    Milliseconds    INT                      NOT NULL,
    Bytes           INT,
    UnitPrice       DECIMAL(10, 2)           NOT NULL,
    MediaTypeID     INT                      NOT NULL,
    GenreID         INT,
    AlbumID         NATIONAL VARCHAR(160),
    PRIMARY KEY (TrackID)
)ENGINE=MYISAM
;



-- 
-- TABLE: Genre 
--

CREATE TABLE Genre(
    GenreID    INT                      NOT NULL,
    Name       NATIONAL VARCHAR(120),
    PRIMARY KEY (GenreID)
)ENGINE=MYISAM
;



-- 
-- TABLE: InvoiceLine 
--

CREATE TABLE InvoiceLine(
    InvoiceLineID    INT               NOT NULL,
    UnitPrice        DECIMAL(10, 2)    NOT NULL,
    Quantity         INT               NOT NULL,
    TrackID          INT               NOT NULL,
    PRIMARY KEY (InvoiceLineID)
)ENGINE=MYISAM
;



-- 
-- TABLE: MediaType 
--

CREATE TABLE MediaType(
    MediaTypeID    INT                      NOT NULL,
    Name           NATIONAL VARCHAR(120),
    PRIMARY KEY (MediaTypeID)
)ENGINE=MYISAM
;



-- 
-- TABLE: Playlist 
--

CREATE TABLE Playlist(
    PlaylistID    INT                      NOT NULL,
    Name          NATIONAL VARCHAR(120),
    PRIMARY KEY (PlaylistID)
)ENGINE=MYISAM
;



-- 
-- TABLE: PlaylistTrack 
--

CREATE TABLE PlaylistTrack(
    TrackID       INT    NOT NULL,
    PlaylistID    INT    NOT NULL,
    PRIMARY KEY (TrackID, PlaylistID)
)ENGINE=MYISAM
;



-- 
-- TABLE: Album 
--

ALTER TABLE Album ADD CONSTRAINT RefArtist6 
    FOREIGN KEY (ArtistID)
    REFERENCES Artist(ArtistID)
;


-- 
-- TABLE: Customer 
--

ALTER TABLE Customer ADD CONSTRAINT `RefDim.Employee8` 
    FOREIGN KEY (EmployeeID)
    REFERENCES `Dim.Employee`(EmployeeID)
;


-- 
-- TABLE: `Dim.Employee` 
--

ALTER TABLE `Dim.Employee` ADD CONSTRAINT `RefDim.Employee7` 
    FOREIGN KEY (ReportsTo)
    REFERENCES `Dim.Employee`(EmployeeID)
;


-- 
-- TABLE: `Fact.Invoice` 
--

ALTER TABLE `Fact.Invoice` ADD CONSTRAINT RefCustomer9 
    FOREIGN KEY (CustomerID)
    REFERENCES Customer(CustomerID)
;


-- 
-- TABLE: `Fact.Track` 
--

ALTER TABLE `Fact.Track` ADD CONSTRAINT RefMediaType3 
    FOREIGN KEY (MediaTypeID)
    REFERENCES MediaType(MediaTypeID)
;

ALTER TABLE `Fact.Track` ADD CONSTRAINT RefGenre4 
    FOREIGN KEY (GenreID)
    REFERENCES Genre(GenreID)
;

ALTER TABLE `Fact.Track` ADD CONSTRAINT RefAlbum5 
    FOREIGN KEY (AlbumID)
    REFERENCES Album(AlbumID)
;


-- 
-- TABLE: InvoiceLine 
--

ALTER TABLE InvoiceLine ADD CONSTRAINT `RefFact.Track11` 
    FOREIGN KEY (TrackID)
    REFERENCES `Fact.Track`(TrackID)
;


-- 
-- TABLE: PlaylistTrack 
--

ALTER TABLE PlaylistTrack ADD CONSTRAINT `RefFact.Track1` 
    FOREIGN KEY (TrackID)
    REFERENCES `Fact.Track`(TrackID)
;

ALTER TABLE PlaylistTrack ADD CONSTRAINT RefPlaylist2 
    FOREIGN KEY (PlaylistID)
    REFERENCES Playlist(PlaylistID)
;


