/*
 * ER/Studio Data Architect SQL Code Generation
 * Project :      Chinook_DimensionalModel.DM1
 *
 * Date Created : Wednesday, February 06, 2019 18:47:15
 * Target DBMS : Microsoft SQL Server 2017
 */

/* 
 * TABLE: Album 
 */

CREATE TABLE Album(
    AlbumID     nvarchar(160)    NOT NULL,
    Title       nvarchar(100)    NOT NULL,
    ArtistID    int              NOT NULL,
    CONSTRAINT PK10 PRIMARY KEY NONCLUSTERED (AlbumID)
)
go



IF OBJECT_ID('Album') IS NOT NULL
    PRINT '<<< CREATED TABLE Album >>>'
ELSE
    PRINT '<<< FAILED CREATING TABLE Album >>>'
go

/* 
 * TABLE: Artist 
 */

CREATE TABLE Artist(
    ArtistID    int              NOT NULL,
    Name        nvarchar(120)    NULL,
    CONSTRAINT PK11 PRIMARY KEY NONCLUSTERED (ArtistID)
)
go



IF OBJECT_ID('Artist') IS NOT NULL
    PRINT '<<< CREATED TABLE Artist >>>'
ELSE
    PRINT '<<< FAILED CREATING TABLE Artist >>>'
go

/* 
 * TABLE: Customer 
 */

CREATE TABLE Customer(
    CustomerID    int             NOT NULL,
    Phone         nvarchar(24)    NULL,
    Fax           nvarchar(24)    NULL,
    Email         nvarchar(60)    NOT NULL,
    FirstName     nvarchar(40)    NOT NULL,
    LastName      nvarchar(20)    NOT NULL,
    Company       nvarchar(80)    NULL,
    Address       nvarchar(70)    NULL,
    City          nvarchar(40)    NULL,
    State         nvarchar(40)    NULL,
    Country       nvarchar(40)    NULL,
    PostalCode    nvarchar(10)    NULL,
    EmployeeID    int             NULL,
    CONSTRAINT PK4 PRIMARY KEY NONCLUSTERED (CustomerID)
)
go



IF OBJECT_ID('Customer') IS NOT NULL
    PRINT '<<< CREATED TABLE Customer >>>'
ELSE
    PRINT '<<< FAILED CREATING TABLE Customer >>>'
go

/* 
 * TABLE: [Dim.Employee] 
 */

CREATE TABLE [Dim.Employee](
    EmployeeID    int             NOT NULL,
    ReportsTo     int             NULL,
    LastName      nvarchar(20)    NOT NULL,
    FirstName     nvarchar(20)    NOT NULL,
    Title         nvarchar(10)    NULL,
    Birthdate     datetime        NULL,
    HireDate      datetime        NULL,
    Address       nvarchar(70)    NULL,
    City          nvarchar(40)    NULL,
    State         nvarchar(40)    NULL,
    Country       nvarchar(40)    NULL,
    PostalCode    nvarchar(10)    NULL,
    Phone         nvarchar(24)    NULL,
    Fax           nvarchar(24)    NULL,
    Email         nvarchar(60)    NULL,
    CONSTRAINT PK5 PRIMARY KEY NONCLUSTERED (EmployeeID)
)
go



IF OBJECT_ID('Dim.Employee') IS NOT NULL
    PRINT '<<< CREATED TABLE Dim.Employee >>>'
ELSE
    PRINT '<<< FAILED CREATING TABLE Dim.Employee >>>'
go

/* 
 * TABLE: [Fact.Invoice] 
 */

CREATE TABLE [Fact.Invoice](
    InvoiceID         varchar(30)    NOT NULL,
    InvoiceDate       date           NOT NULL,
    BillingAddress    varchar(30)    NOT NULL,
    BillingCity       varchar(30)    NOT NULL,
    BillingState      varchar(30)    NOT NULL,
    BillingCountry    varchar(30)    NOT NULL,
    BillingZipCode    varchar(10)    NOT NULL,
    Total             float          NOT NULL,
    CustomerID        int            NOT NULL
)
go



IF OBJECT_ID('Fact.Invoice') IS NOT NULL
    PRINT '<<< CREATED TABLE Fact.Invoice >>>'
ELSE
    PRINT '<<< FAILED CREATING TABLE Fact.Invoice >>>'
go

/* 
 * TABLE: [Fact.Track] 
 */

CREATE TABLE [Fact.Track](
    TrackID         int               NOT NULL,
    Name            nvarchar(200)     NOT NULL,
    Composer        nvarchar(220)     NOT NULL,
    Milliseconds    int               NOT NULL,
    Bytes           int               NULL,
    UnitPrice       numeric(10, 2)    NOT NULL,
    MediaTypeID     int               NOT NULL,
    GenreID         int               NULL,
    AlbumID         nvarchar(160)     NULL,
    CONSTRAINT PK2 PRIMARY KEY NONCLUSTERED (TrackID)
)
go



IF OBJECT_ID('Fact.Track') IS NOT NULL
    PRINT '<<< CREATED TABLE Fact.Track >>>'
ELSE
    PRINT '<<< FAILED CREATING TABLE Fact.Track >>>'
go

/* 
 * TABLE: Genre 
 */

CREATE TABLE Genre(
    GenreID    int              NOT NULL,
    Name       nvarchar(120)    NULL,
    CONSTRAINT PK9 PRIMARY KEY NONCLUSTERED (GenreID)
)
go



IF OBJECT_ID('Genre') IS NOT NULL
    PRINT '<<< CREATED TABLE Genre >>>'
ELSE
    PRINT '<<< FAILED CREATING TABLE Genre >>>'
go

/* 
 * TABLE: InvoiceLine 
 */

CREATE TABLE InvoiceLine(
    InvoiceLineID    int               NOT NULL,
    UnitPrice        numeric(10, 2)    NOT NULL,
    Quantity         int               NOT NULL,
    TrackID          int               NOT NULL,
    CONSTRAINT PK3 PRIMARY KEY NONCLUSTERED (InvoiceLineID)
)
go



IF OBJECT_ID('InvoiceLine') IS NOT NULL
    PRINT '<<< CREATED TABLE InvoiceLine >>>'
ELSE
    PRINT '<<< FAILED CREATING TABLE InvoiceLine >>>'
go

/* 
 * TABLE: MediaType 
 */

CREATE TABLE MediaType(
    MediaTypeID    int              NOT NULL,
    Name           nvarchar(120)    NULL,
    CONSTRAINT PK8 PRIMARY KEY NONCLUSTERED (MediaTypeID)
)
go



IF OBJECT_ID('MediaType') IS NOT NULL
    PRINT '<<< CREATED TABLE MediaType >>>'
ELSE
    PRINT '<<< FAILED CREATING TABLE MediaType >>>'
go

/* 
 * TABLE: Playlist 
 */

CREATE TABLE Playlist(
    PlaylistID    int              NOT NULL,
    Name          nvarchar(120)    NULL,
    CONSTRAINT PK7 PRIMARY KEY NONCLUSTERED (PlaylistID)
)
go



IF OBJECT_ID('Playlist') IS NOT NULL
    PRINT '<<< CREATED TABLE Playlist >>>'
ELSE
    PRINT '<<< FAILED CREATING TABLE Playlist >>>'
go

/* 
 * TABLE: PlaylistTrack 
 */

CREATE TABLE PlaylistTrack(
    TrackID       int    NOT NULL,
    PlaylistID    int    NOT NULL,
    CONSTRAINT PK6 PRIMARY KEY NONCLUSTERED (TrackID, PlaylistID)
)
go



IF OBJECT_ID('PlaylistTrack') IS NOT NULL
    PRINT '<<< CREATED TABLE PlaylistTrack >>>'
ELSE
    PRINT '<<< FAILED CREATING TABLE PlaylistTrack >>>'
go

/* 
 * TABLE: Album 
 */

ALTER TABLE Album ADD CONSTRAINT RefArtist6 
    FOREIGN KEY (ArtistID)
    REFERENCES Artist(ArtistID)
go


/* 
 * TABLE: Customer 
 */

ALTER TABLE Customer ADD CONSTRAINT [RefDim.Employee8] 
    FOREIGN KEY (EmployeeID)
    REFERENCES [Dim.Employee](EmployeeID)
go


/* 
 * TABLE: [Dim.Employee] 
 */

ALTER TABLE [Dim.Employee] ADD CONSTRAINT [RefDim.Employee7] 
    FOREIGN KEY (ReportsTo)
    REFERENCES [Dim.Employee](EmployeeID)
go


/* 
 * TABLE: [Fact.Invoice] 
 */

ALTER TABLE [Fact.Invoice] ADD CONSTRAINT RefCustomer9 
    FOREIGN KEY (CustomerID)
    REFERENCES Customer(CustomerID)
go


/* 
 * TABLE: [Fact.Track] 
 */

ALTER TABLE [Fact.Track] ADD CONSTRAINT RefMediaType3 
    FOREIGN KEY (MediaTypeID)
    REFERENCES MediaType(MediaTypeID)
go

ALTER TABLE [Fact.Track] ADD CONSTRAINT RefGenre4 
    FOREIGN KEY (GenreID)
    REFERENCES Genre(GenreID)
go

ALTER TABLE [Fact.Track] ADD CONSTRAINT RefAlbum5 
    FOREIGN KEY (AlbumID)
    REFERENCES Album(AlbumID)
go


/* 
 * TABLE: InvoiceLine 
 */

ALTER TABLE InvoiceLine ADD CONSTRAINT [RefFact.Track11] 
    FOREIGN KEY (TrackID)
    REFERENCES [Fact.Track](TrackID)
go


/* 
 * TABLE: PlaylistTrack 
 */

ALTER TABLE PlaylistTrack ADD CONSTRAINT [RefFact.Track1] 
    FOREIGN KEY (TrackID)
    REFERENCES [Fact.Track](TrackID)
go

ALTER TABLE PlaylistTrack ADD CONSTRAINT RefPlaylist2 
    FOREIGN KEY (PlaylistID)
    REFERENCES Playlist(PlaylistID)
go


