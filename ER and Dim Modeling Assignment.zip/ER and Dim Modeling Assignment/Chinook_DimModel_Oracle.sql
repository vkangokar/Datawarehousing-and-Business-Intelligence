--
-- ER/Studio Data Architect SQL Code Generation
-- Project :      Chinook_DimensionalModel.DM1
--
-- Date Created : Wednesday, February 06, 2019 18:43:50
-- Target DBMS : Oracle 11g
--

-- 
-- TABLE: Album 
--

CREATE TABLE Album(
    AlbumID     NVARCHAR2(160)    NOT NULL,
    Title       NVARCHAR2(100)    NOT NULL,
    ArtistID    NUMBER(38, 0)     NOT NULL,
    CONSTRAINT PK10 PRIMARY KEY (AlbumID)
)
;



-- 
-- TABLE: Artist 
--

CREATE TABLE Artist(
    ArtistID    NUMBER(38, 0)     NOT NULL,
    Name        NVARCHAR2(120),
    CONSTRAINT PK11 PRIMARY KEY (ArtistID)
)
;



-- 
-- TABLE: Customer 
--

CREATE TABLE Customer(
    CustomerID    NUMBER(38, 0)    NOT NULL,
    Phone         NVARCHAR2(24),
    Fax           NVARCHAR2(24),
    Email         NVARCHAR2(60)    NOT NULL,
    FirstName     NVARCHAR2(40)    NOT NULL,
    LastName      NVARCHAR2(20)    NOT NULL,
    Company       NVARCHAR2(80),
    Address       NVARCHAR2(70),
    City          NVARCHAR2(40),
    State         NVARCHAR2(40),
    Country       NVARCHAR2(40),
    PostalCode    NVARCHAR2(10),
    EmployeeID    NUMBER(38, 0),
    CONSTRAINT PK4 PRIMARY KEY (CustomerID)
)
;



-- 
-- TABLE: "Dim.Employee" 
--

CREATE TABLE "Dim.Employee"(
    EmployeeID    NUMBER(38, 0)    NOT NULL,
    ReportsTo     NUMBER(38, 0),
    LastName      NVARCHAR2(20)    NOT NULL,
    FirstName     NVARCHAR2(20)    NOT NULL,
    Title         NVARCHAR2(10),
    Birthdate     TIMESTAMP(6),
    HireDate      TIMESTAMP(6),
    Address       NVARCHAR2(70),
    City          NVARCHAR2(40),
    State         NVARCHAR2(40),
    Country       NVARCHAR2(40),
    PostalCode    NVARCHAR2(10),
    Phone         NVARCHAR2(24),
    Fax           NVARCHAR2(24),
    Email         NVARCHAR2(60),
    CONSTRAINT PK5 PRIMARY KEY (EmployeeID)
)
;



-- 
-- TABLE: "Fact.Invoice" 
--

CREATE TABLE "Fact.Invoice"(
    InvoiceID         VARCHAR2(30)     NOT NULL,
    InvoiceDate       DATE             NOT NULL,
    BillingAddress    VARCHAR2(30)     NOT NULL,
    BillingCity       VARCHAR2(30)     NOT NULL,
    BillingState      VARCHAR2(30)     NOT NULL,
    BillingCountry    VARCHAR2(30)     NOT NULL,
    BillingZipCode    VARCHAR2(10)     NOT NULL,
    Total             BINARY_FLOAT     NOT NULL,
    CustomerID        NUMBER(38, 0)    NOT NULL
)
;



-- 
-- TABLE: "Fact.Track" 
--

CREATE TABLE "Fact.Track"(
    TrackID         NUMBER(38, 0)     NOT NULL,
    Name            NVARCHAR2(200)    NOT NULL,
    Composer        NVARCHAR2(220)    NOT NULL,
    Milliseconds    NUMBER(38, 0)     NOT NULL,
    Bytes           NUMBER(38, 0),
    UnitPrice       NUMBER(10, 2)     NOT NULL,
    MediaTypeID     NUMBER(38, 0)     NOT NULL,
    GenreID         NUMBER(38, 0),
    AlbumID         NVARCHAR2(160),
    CONSTRAINT PK2 PRIMARY KEY (TrackID)
)
;



-- 
-- TABLE: Genre 
--

CREATE TABLE Genre(
    GenreID    NUMBER(38, 0)     NOT NULL,
    Name       NVARCHAR2(120),
    CONSTRAINT PK9 PRIMARY KEY (GenreID)
)
;



-- 
-- TABLE: InvoiceLine 
--

CREATE TABLE InvoiceLine(
    InvoiceLineID    NUMBER(38, 0)    NOT NULL,
    UnitPrice        NUMBER(10, 2)    NOT NULL,
    Quantity         NUMBER(38, 0)    NOT NULL,
    TrackID          NUMBER(38, 0)    NOT NULL,
    CONSTRAINT PK3 PRIMARY KEY (InvoiceLineID)
)
;



-- 
-- TABLE: MediaType 
--

CREATE TABLE MediaType(
    MediaTypeID    NUMBER(38, 0)     NOT NULL,
    Name           NVARCHAR2(120),
    CONSTRAINT PK8 PRIMARY KEY (MediaTypeID)
)
;



-- 
-- TABLE: Playlist 
--

CREATE TABLE Playlist(
    PlaylistID    NUMBER(38, 0)     NOT NULL,
    Name          NVARCHAR2(120),
    CONSTRAINT PK7 PRIMARY KEY (PlaylistID)
)
;



-- 
-- TABLE: PlaylistTrack 
--

CREATE TABLE PlaylistTrack(
    TrackID       NUMBER(38, 0)    NOT NULL,
    PlaylistID    NUMBER(38, 0)    NOT NULL,
    CONSTRAINT PK6 PRIMARY KEY (TrackID, PlaylistID)
)
;



-- 
-- TABLE: Album 
--

ALTER TABLE Album ADD CONSTRAINT RefArtist6 
    FOREIGN KEY (ArtistID)
    REFERENCES Artist(ArtistID)
;


-- 
-- TABLE: Customer 
--

ALTER TABLE Customer ADD CONSTRAINT "RefDim.Employee8" 
    FOREIGN KEY (EmployeeID)
    REFERENCES "Dim.Employee"(EmployeeID)
;


-- 
-- TABLE: "Dim.Employee" 
--

ALTER TABLE "Dim.Employee" ADD CONSTRAINT "RefDim.Employee7" 
    FOREIGN KEY (ReportsTo)
    REFERENCES "Dim.Employee"(EmployeeID)
;


-- 
-- TABLE: "Fact.Invoice" 
--

ALTER TABLE "Fact.Invoice" ADD CONSTRAINT RefCustomer9 
    FOREIGN KEY (CustomerID)
    REFERENCES Customer(CustomerID)
;


-- 
-- TABLE: "Fact.Track" 
--

ALTER TABLE "Fact.Track" ADD CONSTRAINT RefMediaType3 
    FOREIGN KEY (MediaTypeID)
    REFERENCES MediaType(MediaTypeID)
;

ALTER TABLE "Fact.Track" ADD CONSTRAINT RefGenre4 
    FOREIGN KEY (GenreID)
    REFERENCES Genre(GenreID)
;

ALTER TABLE "Fact.Track" ADD CONSTRAINT RefAlbum5 
    FOREIGN KEY (AlbumID)
    REFERENCES Album(AlbumID)
;


-- 
-- TABLE: InvoiceLine 
--

ALTER TABLE InvoiceLine ADD CONSTRAINT "RefFact.Track11" 
    FOREIGN KEY (TrackID)
    REFERENCES "Fact.Track"(TrackID)
;


-- 
-- TABLE: PlaylistTrack 
--

ALTER TABLE PlaylistTrack ADD CONSTRAINT "RefFact.Track1" 
    FOREIGN KEY (TrackID)
    REFERENCES "Fact.Track"(TrackID)
;

ALTER TABLE PlaylistTrack ADD CONSTRAINT RefPlaylist2 
    FOREIGN KEY (PlaylistID)
    REFERENCES Playlist(PlaylistID)
;


