--
-- ER/Studio Data Architect SQL Code Generation
-- Project :      University.DM1
--
-- Date Created : Wednesday, February 06, 2019 16:37:31
-- Target DBMS : Oracle 11g
--

-- 
-- TABLE: Address 
--

CREATE TABLE Address(
    PERMANENT_ADDRESS_ID    NUMBER(38, 0)     NOT NULL,
    CURRENT_ADDRESS_ID      NUMBER(38, 0)     NOT NULL,
    STUDENT_ID              NUMBER(38, 0)     NOT NULL,
    STUDENT_USERNAME        NVARCHAR2(100)    NOT NULL,
    STATE                   NVARCHAR2(100),
    "ZIP-CODE"              NUMBER(38, 0)     NOT NULL,
    CITY                    NVARCHAR2(100),
    CONSTRAINT PK2 PRIMARY KEY (PERMANENT_ADDRESS_ID, CURRENT_ADDRESS_ID)
)
;



-- 
-- TABLE: Class 
--

CREATE TABLE Class(
    CLASS_ID      NUMBER(38, 0)    NOT NULL,
    CLASS_TYPE    NVARCHAR2(10)    NOT NULL,
    CONSTRAINT PK8 PRIMARY KEY (CLASS_ID)
)
;



-- 
-- TABLE: College 
--

CREATE TABLE College(
    COLLEGE_ID       NUMBER(38, 0)     NOT NULL,
    DEPT_CODE        NUMBER(38, 0)     NOT NULL,
    COLLEGE_NAME     NVARCHAR2(100)    NOT NULL,
    OFFICE_NUMBER    NUMBER(38, 0),
    OFFICE_PHONE     NUMBER(38, 0),
    CONSTRAINT PK7 PRIMARY KEY (COLLEGE_ID)
)
;



-- 
-- TABLE: College_To_Department 
--

CREATE TABLE College_To_Department(
    COLLEGE_ID    NUMBER(38, 0)    NOT NULL,
    DEPT_NAME     NVARCHAR2(18)    NOT NULL,
    DEPT_CODE     NUMBER(38, 0)    NOT NULL,
    CONSTRAINT PK3 PRIMARY KEY (COLLEGE_ID, DEPT_NAME, DEPT_CODE)
)
;



-- 
-- TABLE: Course 
--

CREATE TABLE Course(
    COURSE_NUMBER    NUMBER(38, 0)     NOT NULL,
    COURSE_NAME      NVARCHAR2(100)    NOT NULL,
    COURSE_DESC      NVARCHAR2(100),
    CREDITS          NUMBER(38, 0)     NOT NULL,
    LEVEL            NUMBER(38, 0)     NOT NULL,
    DEPT_NAME        NVARCHAR2(18)     NOT NULL,
    DEPT_CODE        NUMBER(38, 0)     NOT NULL,
    CONSTRAINT PK4 PRIMARY KEY (COURSE_NUMBER)
)
;



-- 
-- TABLE: Department 
--

CREATE TABLE Department(
    DEPT_NAME        NVARCHAR2(18)    NOT NULL,
    DEPT_CODE        NUMBER(38, 0)    NOT NULL,
    COLLEGE_ID       NUMBER(38, 0)    NOT NULL,
    OFFICE_NUMBER    NUMBER(38, 0),
    OFFICE_PHONE     NUMBER(38, 0),
    CONSTRAINT PK6 PRIMARY KEY (DEPT_NAME, DEPT_CODE)
)
;



-- 
-- TABLE: Grade_Report 
--

CREATE TABLE Grade_Report(
    STUDENT_ID          NUMBER(38, 0)     NOT NULL,
    SECTION_NUMBER      NUMBER(38, 0)     NOT NULL,
    STUDENT_USERNAME    NVARCHAR2(100)    NOT NULL,
    NUMERIC_GRADE       NUMBER(38, 0)     NOT NULL,
    LETTER_GRADE        CHAR(10)          NOT NULL,
    COURSE_NUMBER       NUMBER(38, 0)     NOT NULL,
    CONSTRAINT PK10 PRIMARY KEY (STUDENT_ID, SECTION_NUMBER, STUDENT_USERNAME)
)
;



-- 
-- TABLE: Section 
--

CREATE TABLE Section(
    SECTION_NUMBER    NUMBER(38, 0)     NOT NULL,
    COURSE_NUMBER     NUMBER(38, 0)     NOT NULL,
    SEMESTER          NUMBER(38, 0)     NOT NULL,
    YEAR              TIMESTAMP(6),
    INSTRUCTOR        NVARCHAR2(100)    NOT NULL,
    CONSTRAINT PK5 PRIMARY KEY (SECTION_NUMBER, COURSE_NUMBER)
)
;



-- 
-- TABLE: Student 
--

CREATE TABLE Student(
    STUDENT_ID          NUMBER(38, 0)     NOT NULL,
    STUDENT_USERNAME    NVARCHAR2(100)    NOT NULL,
    COLLEGE_ID          NUMBER(38, 0)     NOT NULL,
    PHONE               NUMBER(38, 0),
    STUDENT_NAME        NVARCHAR2(100),
    SEX                 CHAR(10)          NOT NULL,
    BIRTHDATE           DATE,
    DEGREE              NVARCHAR2(100)    NOT NULL,
    CLASS_ID            NUMBER(38, 0)     NOT NULL,
    CONSTRAINT PK1 PRIMARY KEY (STUDENT_ID, STUDENT_USERNAME)
)
;



-- 
-- TABLE: Address 
--

ALTER TABLE Address ADD CONSTRAINT RefStudent1 
    FOREIGN KEY (STUDENT_ID, STUDENT_USERNAME)
    REFERENCES Student(STUDENT_ID, STUDENT_USERNAME)
;


-- 
-- TABLE: College_To_Department 
--

ALTER TABLE College_To_Department ADD CONSTRAINT RefCollege8 
    FOREIGN KEY (COLLEGE_ID)
    REFERENCES College(COLLEGE_ID)
;

ALTER TABLE College_To_Department ADD CONSTRAINT RefDepartment9 
    FOREIGN KEY (DEPT_NAME, DEPT_CODE)
    REFERENCES Department(DEPT_NAME, DEPT_CODE)
;


-- 
-- TABLE: Course 
--

ALTER TABLE Course ADD CONSTRAINT RefDepartment10 
    FOREIGN KEY (DEPT_NAME, DEPT_CODE)
    REFERENCES Department(DEPT_NAME, DEPT_CODE)
;


-- 
-- TABLE: Grade_Report 
--

ALTER TABLE Grade_Report ADD CONSTRAINT RefStudent17 
    FOREIGN KEY (STUDENT_ID, STUDENT_USERNAME)
    REFERENCES Student(STUDENT_ID, STUDENT_USERNAME)
;

ALTER TABLE Grade_Report ADD CONSTRAINT RefSection18 
    FOREIGN KEY (SECTION_NUMBER, COURSE_NUMBER)
    REFERENCES Section(SECTION_NUMBER, COURSE_NUMBER)
;


-- 
-- TABLE: Section 
--

ALTER TABLE Section ADD CONSTRAINT RefCourse11 
    FOREIGN KEY (COURSE_NUMBER)
    REFERENCES Course(COURSE_NUMBER)
;


-- 
-- TABLE: Student 
--

ALTER TABLE Student ADD CONSTRAINT RefCollege4 
    FOREIGN KEY (COLLEGE_ID)
    REFERENCES College(COLLEGE_ID)
;

ALTER TABLE Student ADD CONSTRAINT RefClass14 
    FOREIGN KEY (CLASS_ID)
    REFERENCES Class(CLASS_ID)
;


