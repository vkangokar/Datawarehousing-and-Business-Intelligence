--
-- ER/Studio Data Architect SQL Code Generation
-- Project :      University_ER.DM1
--
-- Date Created : Wednesday, February 06, 2019 16:13:35
-- Target DBMS : Oracle 11g
--

-- 
-- TABLE: Address 
--

CREATE TABLE Address(
    Permanent_Address_ID    VARCHAR2(10)     NOT NULL,
    Current_Address_ID      VARCHAR2(30)     NOT NULL,
    Std_Username            VARCHAR2(10),
    Std_Id                  NUMBER(38, 0),
    City                    VARCHAR2(30)     NOT NULL,
    States                   VARCHAR2(30)     NOT NULL,
    ZipCode                 VARCHAR2(30)     NOT NULL,
    CONSTRAINT PK9 PRIMARY KEY (Permanent_Address_ID, Current_Address_ID)
)
;



-- 
-- TABLE: College 
--

CREATE TABLE College(
    College_ID         VARCHAR2(10)     NOT NULL,
    Department_Code    VARCHAR2(30)     NOT NULL,
    Name               VARCHAR2(30)     NOT NULL,
    Office_number      NUMBER(38, 0)    NOT NULL,
    Office_Phone       NUMBER(38, 0)    NOT NULL,
    CONSTRAINT PK2 PRIMARY KEY (College_ID)
)
;



-- 
-- TABLE: College_Department 
--

CREATE TABLE College_Department(
    Name               VARCHAR2(40)    NOT NULL,
    Department_Code    VARCHAR2(30)    NOT NULL,
    College_ID         VARCHAR2(10)    NOT NULL,
    CONSTRAINT PK8 PRIMARY KEY (Name, Department_Code, College_ID)
)
;



-- 
-- TABLE: Course 
--

CREATE TABLE Course(
    Course_Number               NUMBER(38, 0)    NOT NULL,
    Name                        VARCHAR2(40)     NOT NULL,
    Department_Code             VARCHAR2(30)     NOT NULL,
    Description                 VARCHAR2(30)     NOT NULL,
    Number_of_Semester_hours    NUMBER(38, 0),
    Levels                       VARCHAR2(30)     NOT NULL,
    Offering_Department         VARCHAR2(30)     NOT NULL,
    CONSTRAINT PK4 PRIMARY KEY (Course_Number)
)
;



-- 
-- TABLE: Department 
--

CREATE TABLE Department(
    Name               VARCHAR2(40)     NOT NULL,
    Department_Code    VARCHAR2(30)     NOT NULL,
    Office_Number      NUMBER(38, 0)    NOT NULL,
    Office_Phone       NUMBER(38, 0)    NOT NULL,
    College            VARCHAR2(30)     NOT NULL,
    CONSTRAINT PK3 PRIMARY KEY (Name, Department_Code)
)
;



-- 
-- TABLE: Grade_report 
--

CREATE TABLE Grade_report(
    Std_Username      VARCHAR2(10)     NOT NULL,
    Std_Id            NUMBER(38, 0)    NOT NULL,
    Section_Number    NUMBER(38, 0)    NOT NULL,
    Student           VARCHAR2(30)     NOT NULL,
    Section           NUMBER(38, 0)    NOT NULL,
    Letter_Grade      CHAR(30)         NOT NULL,
    Numeric_Grade     NUMBER(38, 0)    NOT NULL,
    Course_Number     NUMBER(38, 0)    NOT NULL,
    CONSTRAINT PK7 PRIMARY KEY (Std_Username, Std_Id, Section_Number)
)
;



-- 
-- TABLE: Section 
--

CREATE TABLE Section(
    Section_Number    NUMBER(38, 0)    NOT NULL,
    Course_Number     NUMBER(38, 0)    NOT NULL,
    Instructor        VARCHAR2(30)     NOT NULL,
    Semester          NUMBER(38, 0)    NOT NULL,
    Year              DATE             NOT NULL,
    Course            VARCHAR2(30)     NOT NULL,
    CONSTRAINT PK6 PRIMARY KEY (Section_Number, Course_Number)
)
;



-- 
-- TABLE: Student 
--

CREATE TABLE Student(
    Std_Username           VARCHAR2(10)     NOT NULL,
    Std_Id                 NUMBER(38, 0)    NOT NULL,
    College_ID             VARCHAR2(10)     NOT NULL,
    Std_Name               VARCHAR2(30)     NOT NULL,
    Phone                  NUMBER(38, 0)    NOT NULL,
    Birthdate              DATE             NOT NULL,
    Sex                    VARCHAR2(10)     NOT NULL,
    Class                  VARCHAR2(30)     NOT NULL,
    College                VARCHAR2(30)     NOT NULL,
    Major_department       VARCHAR2(30)     NOT NULL,
    Minor_department       VARCHAR2(40)     NOT NULL,
    Certificate_program    VARCHAR2(30)     NOT NULL,
    Degre_program          VARCHAR2(30)     NOT NULL,
    CONSTRAINT PK1 PRIMARY KEY (Std_Username, Std_Id)
)
;



-- 
-- TABLE: Address 
--

ALTER TABLE Address ADD CONSTRAINT RefStudent19 
    FOREIGN KEY (Std_Username, Std_Id)
    REFERENCES Student(Std_Username, Std_Id)
;


-- 
-- TABLE: College_Department 
--

ALTER TABLE College_Department ADD CONSTRAINT RefDepartment17 
    FOREIGN KEY (Name, Department_Code)
    REFERENCES Department(Name, Department_Code)
;

ALTER TABLE College_Department ADD CONSTRAINT RefCollege18 
    FOREIGN KEY (College_ID)
    REFERENCES College(College_ID)
;


-- 
-- TABLE: Course 
--

ALTER TABLE Course ADD CONSTRAINT RefDepartment13 
    FOREIGN KEY (Name, Department_Code)
    REFERENCES Department(Name, Department_Code)
;


-- 
-- TABLE: Grade_report 
--

ALTER TABLE Grade_report ADD CONSTRAINT RefStudent8 
    FOREIGN KEY (Std_Username, Std_Id)
    REFERENCES Student(Std_Username, Std_Id)
;

ALTER TABLE Grade_report ADD CONSTRAINT RefSection14 
    FOREIGN KEY (Section_Number, Course_Number)
    REFERENCES Section(Section_Number, Course_Number)
;


-- 
-- TABLE: Section 
--

ALTER TABLE Section ADD CONSTRAINT RefCourse7 
    FOREIGN KEY (Course_Number)
    REFERENCES Course(Course_Number)
;


-- 
-- TABLE: Student 
--

ALTER TABLE Student ADD CONSTRAINT RefCollege9 
    FOREIGN KEY (College_ID)
    REFERENCES College(College_ID)
;


